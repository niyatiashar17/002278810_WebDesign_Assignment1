const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");

const app = express();
const port = 3000;

app.use(bodyParser.json());

(async () => {
  try {
    await mongoose.connect("mongodb://localhost/web_design", {
      useNewUrlParser: true,
    });
    console.log("Connected to MongoDB");
  } catch (error) {
    console.error(error);
  }
})();

const UserSchema = new mongoose.Schema({
  fullName: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
});

const User = mongoose.model("User", UserSchema);

app.post("/user/create", async (req, res) => {
  const { fullName, email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: "Invalid email or password." });
  }

  if (password.length < 8) {
    return res
      .status(400)
      .json({ message: "Password must be at least 8 characters long." });
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  const newUser = new User({ fullName, email, password: hashedPassword });

  try {
    await newUser.save();
    res.json({ message: "User created successfully." });
  } catch (error) {
    res.status(400).json({ message: "Email is already in use." });
  }
});

app.put("/user/edit", async (req, res) => {
  const { fullName, password } = req.body;

  const user = await User.findOne({ email: req.body.email });
  if (!user) {
    return res.status(404).json({ message: "User not found." });
  }

  if (!fullName || !password) {
    return res.status(400).json({ message: "Invalid full name or password." });
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  user.fullName = fullName;
  user.password = hashedPassword;

  try {
    await user.save();
    res.json({ message: "User details updated successfully." });
  } catch (error) {
    res.status(500).json({ message: "Internal server error." });
  }
});

app.delete("/user/delete", async (req, res) => {
  const email = req.body.email;

  try {
    const result = await User.deleteOne({ email });
    if (result.deletedCount === 0) {
      return res.status(404).json({ message: "User not found." });
    }
    res.json({ message: "User deleted successfully." });
  } catch (error) {
    res.status(500).json({ message: "Internal server error." });
  }
});

app.get("/user/getAll", async (req, res) => {
  try {
    const users = await User.find();
    res.json(users);
    console.log(users);
  } catch (error) {
    res.status(500).json({ message: "Internal server error." });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
